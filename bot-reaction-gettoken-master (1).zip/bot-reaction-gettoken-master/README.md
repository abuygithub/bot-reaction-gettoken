# Usage
1. apt install php -y
2. php setting.php       #untuk set Login etc.
3. php token.php         #untuk get token
* jika sudah / gagal, check dulu login facebook di browser untuk ijin akses.
4. php run.php              #Untuk menjalankan BOT.

# NB
token.php untuk mengambil token dan menyimpannya di token.txt . Cukup 1x get lalu perintah run.php. kecuali jika tokennya expired, ambil token ulang.

# Thanks to
tomiashari [here](https://github.com/tomiashari/fb-autoreaction)
dfmcvn [here](https://github.com/dfmcvn/getFBtoken)